/********************************************************************************
** Form generated from reading UI file 'mainwindow.ui'
**
** Created by: Qt User Interface Compiler version 5.15.9
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MAINWINDOW_H
#define UI_MAINWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QCheckBox>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QLineEdit>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QMenuBar>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QSplitter>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QTextEdit>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MainWindow
{
public:
    QWidget *centralwidget;
    QLabel *image;
    QTextEdit *textEditInfos;
    QSplitter *splitter;
    QWidget *layoutWidget;
    QHBoxLayout *horizontalLayout_3;
    QPushButton *pushButtonMedian;
    QSpinBox *spinBoxMedian;
    QWidget *layoutWidget1;
    QHBoxLayout *horizontalLayout_2;
    QPushButton *pushButtonAverage;
    QSpinBox *spinBoxAverage;
    QPushButton *pushButtonGlobalEq;
    QWidget *layoutWidget2;
    QHBoxLayout *horizontalLayout_6;
    QPushButton *pushButtonBluring;
    QSpinBox *spinBoxBlurring;
    QWidget *layoutWidget3;
    QHBoxLayout *horizontalLayout_5;
    QPushButton *pushButtonHighBoost;
    QDoubleSpinBox *doubleSpinBoxHighBoost;
    QCheckBox *checkBoxSeq;
    QWidget *layoutWidget4;
    QGridLayout *gridLayout;
    QPushButton *pushButtonMirror;
    QPushButton *pushButtonNegativo;
    QPushButton *pushButtonTurnMinus90;
    QPushButton *pushButtonTurnPlus90;
    QPushButton *pushButtonTurnPlus180;
    QWidget *layoutWidget5;
    QGridLayout *gridLayout_2;
    QPushButton *pushButtonBinarizing;
    QSpinBox *spinBoxBinarizing;
    QPushButton *pushButtonDarken;
    QSpinBox *spinBoxDarken;
    QPushButton *pushButtonWhiten;
    QSpinBox *spinBoxWhiten;
    QWidget *layoutWidget6;
    QGridLayout *gridLayout_3;
    QLabel *label_5;
    QSpinBox *spinBoxBinQuatA;
    QLabel *label_6;
    QSpinBox *spinBoxBinQuatB;
    QLabel *label_7;
    QSpinBox *spinBoxBinQuatLimSup;
    QLabel *label_8;
    QSpinBox *spinBoxBinQuatLimInf;
    QPushButton *pushButtonBinQuat;
    QWidget *layoutWidget7;
    QGridLayout *gridLayout_4;
    QLabel *label_2;
    QSpinBox *spinBoxBinTerA;
    QLabel *label_3;
    QSpinBox *spinBoxBinTerB;
    QLabel *label_4;
    QSpinBox *spinBoxBinTerLimSup;
    QPushButton *pushButtonBinTer;
    QWidget *layoutWidget8;
    QHBoxLayout *horizontalLayout;
    QPushButton *pushButton_2;
    QPushButton *pushButtonlaplaciano8;
    QWidget *layoutWidget9;
    QGridLayout *gridLayout_5;
    QPushButton *pushButton;
    QLineEdit *lineImagePath;
    QPushButton *pushButtonLoadPpm;
    QWidget *layoutWidget10;
    QHBoxLayout *horizontalLayout_4;
    QPushButton *ButtonR;
    QPushButton *ButtonG;
    QPushButton *ButtonB;
    QTextEdit *textEditLogs;
    QMenuBar *menubar;
    QStatusBar *statusbar;

    void setupUi(QMainWindow *MainWindow)
    {
        if (MainWindow->objectName().isEmpty())
            MainWindow->setObjectName(QString::fromUtf8("MainWindow"));
        MainWindow->resize(953, 755);
        centralwidget = new QWidget(MainWindow);
        centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
        image = new QLabel(centralwidget);
        image->setObjectName(QString::fromUtf8("image"));
        image->setGeometry(QRect(400, 130, 541, 381));
        image->setFrameShape(QFrame::StyledPanel);
        image->setFrameShadow(QFrame::Plain);
        textEditInfos = new QTextEdit(centralwidget);
        textEditInfos->setObjectName(QString::fromUtf8("textEditInfos"));
        textEditInfos->setGeometry(QRect(400, 20, 541, 91));
        textEditInfos->setReadOnly(true);
        splitter = new QSplitter(centralwidget);
        splitter->setObjectName(QString::fromUtf8("splitter"));
        splitter->setGeometry(QRect(10, 130, 381, 28));
        splitter->setOrientation(Qt::Horizontal);
        layoutWidget = new QWidget(splitter);
        layoutWidget->setObjectName(QString::fromUtf8("layoutWidget"));
        horizontalLayout_3 = new QHBoxLayout(layoutWidget);
        horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
        pushButtonMedian = new QPushButton(layoutWidget);
        pushButtonMedian->setObjectName(QString::fromUtf8("pushButtonMedian"));

        horizontalLayout_3->addWidget(pushButtonMedian);

        spinBoxMedian = new QSpinBox(layoutWidget);
        spinBoxMedian->setObjectName(QString::fromUtf8("spinBoxMedian"));

        horizontalLayout_3->addWidget(spinBoxMedian);

        splitter->addWidget(layoutWidget);
        layoutWidget1 = new QWidget(splitter);
        layoutWidget1->setObjectName(QString::fromUtf8("layoutWidget1"));
        horizontalLayout_2 = new QHBoxLayout(layoutWidget1);
        horizontalLayout_2->setObjectName(QString::fromUtf8("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        pushButtonAverage = new QPushButton(layoutWidget1);
        pushButtonAverage->setObjectName(QString::fromUtf8("pushButtonAverage"));

        horizontalLayout_2->addWidget(pushButtonAverage);

        spinBoxAverage = new QSpinBox(layoutWidget1);
        spinBoxAverage->setObjectName(QString::fromUtf8("spinBoxAverage"));

        horizontalLayout_2->addWidget(spinBoxAverage);

        splitter->addWidget(layoutWidget1);
        pushButtonGlobalEq = new QPushButton(centralwidget);
        pushButtonGlobalEq->setObjectName(QString::fromUtf8("pushButtonGlobalEq"));
        pushButtonGlobalEq->setGeometry(QRect(200, 250, 191, 31));
        layoutWidget2 = new QWidget(centralwidget);
        layoutWidget2->setObjectName(QString::fromUtf8("layoutWidget2"));
        layoutWidget2->setGeometry(QRect(10, 250, 181, 28));
        horizontalLayout_6 = new QHBoxLayout(layoutWidget2);
        horizontalLayout_6->setObjectName(QString::fromUtf8("horizontalLayout_6"));
        horizontalLayout_6->setContentsMargins(0, 0, 0, 0);
        pushButtonBluring = new QPushButton(layoutWidget2);
        pushButtonBluring->setObjectName(QString::fromUtf8("pushButtonBluring"));

        horizontalLayout_6->addWidget(pushButtonBluring);

        spinBoxBlurring = new QSpinBox(layoutWidget2);
        spinBoxBlurring->setObjectName(QString::fromUtf8("spinBoxBlurring"));

        horizontalLayout_6->addWidget(spinBoxBlurring);

        layoutWidget3 = new QWidget(centralwidget);
        layoutWidget3->setObjectName(QString::fromUtf8("layoutWidget3"));
        layoutWidget3->setGeometry(QRect(10, 210, 181, 28));
        horizontalLayout_5 = new QHBoxLayout(layoutWidget3);
        horizontalLayout_5->setObjectName(QString::fromUtf8("horizontalLayout_5"));
        horizontalLayout_5->setContentsMargins(0, 0, 0, 0);
        pushButtonHighBoost = new QPushButton(layoutWidget3);
        pushButtonHighBoost->setObjectName(QString::fromUtf8("pushButtonHighBoost"));

        horizontalLayout_5->addWidget(pushButtonHighBoost);

        doubleSpinBoxHighBoost = new QDoubleSpinBox(layoutWidget3);
        doubleSpinBoxHighBoost->setObjectName(QString::fromUtf8("doubleSpinBoxHighBoost"));

        horizontalLayout_5->addWidget(doubleSpinBoxHighBoost);

        checkBoxSeq = new QCheckBox(centralwidget);
        checkBoxSeq->setObjectName(QString::fromUtf8("checkBoxSeq"));
        checkBoxSeq->setGeometry(QRect(10, 92, 101, 31));
        layoutWidget4 = new QWidget(centralwidget);
        layoutWidget4->setObjectName(QString::fromUtf8("layoutWidget4"));
        layoutWidget4->setGeometry(QRect(10, 290, 201, 81));
        gridLayout = new QGridLayout(layoutWidget4);
        gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        pushButtonMirror = new QPushButton(layoutWidget4);
        pushButtonMirror->setObjectName(QString::fromUtf8("pushButtonMirror"));

        gridLayout->addWidget(pushButtonMirror, 0, 0, 1, 2);

        pushButtonNegativo = new QPushButton(layoutWidget4);
        pushButtonNegativo->setObjectName(QString::fromUtf8("pushButtonNegativo"));

        gridLayout->addWidget(pushButtonNegativo, 0, 2, 1, 1);

        pushButtonTurnMinus90 = new QPushButton(layoutWidget4);
        pushButtonTurnMinus90->setObjectName(QString::fromUtf8("pushButtonTurnMinus90"));

        gridLayout->addWidget(pushButtonTurnMinus90, 1, 0, 1, 1);

        pushButtonTurnPlus90 = new QPushButton(layoutWidget4);
        pushButtonTurnPlus90->setObjectName(QString::fromUtf8("pushButtonTurnPlus90"));

        gridLayout->addWidget(pushButtonTurnPlus90, 1, 1, 1, 1);

        pushButtonTurnPlus180 = new QPushButton(layoutWidget4);
        pushButtonTurnPlus180->setObjectName(QString::fromUtf8("pushButtonTurnPlus180"));

        gridLayout->addWidget(pushButtonTurnPlus180, 1, 2, 1, 1);

        layoutWidget5 = new QWidget(centralwidget);
        layoutWidget5->setObjectName(QString::fromUtf8("layoutWidget5"));
        layoutWidget5->setGeometry(QRect(220, 290, 171, 92));
        gridLayout_2 = new QGridLayout(layoutWidget5);
        gridLayout_2->setObjectName(QString::fromUtf8("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        pushButtonBinarizing = new QPushButton(layoutWidget5);
        pushButtonBinarizing->setObjectName(QString::fromUtf8("pushButtonBinarizing"));

        gridLayout_2->addWidget(pushButtonBinarizing, 0, 0, 1, 1);

        spinBoxBinarizing = new QSpinBox(layoutWidget5);
        spinBoxBinarizing->setObjectName(QString::fromUtf8("spinBoxBinarizing"));

        gridLayout_2->addWidget(spinBoxBinarizing, 0, 1, 1, 1);

        pushButtonDarken = new QPushButton(layoutWidget5);
        pushButtonDarken->setObjectName(QString::fromUtf8("pushButtonDarken"));

        gridLayout_2->addWidget(pushButtonDarken, 1, 0, 1, 1);

        spinBoxDarken = new QSpinBox(layoutWidget5);
        spinBoxDarken->setObjectName(QString::fromUtf8("spinBoxDarken"));

        gridLayout_2->addWidget(spinBoxDarken, 1, 1, 1, 1);

        pushButtonWhiten = new QPushButton(layoutWidget5);
        pushButtonWhiten->setObjectName(QString::fromUtf8("pushButtonWhiten"));

        gridLayout_2->addWidget(pushButtonWhiten, 2, 0, 1, 1);

        spinBoxWhiten = new QSpinBox(layoutWidget5);
        spinBoxWhiten->setObjectName(QString::fromUtf8("spinBoxWhiten"));

        gridLayout_2->addWidget(spinBoxWhiten, 2, 1, 1, 1);

        layoutWidget6 = new QWidget(centralwidget);
        layoutWidget6->setObjectName(QString::fromUtf8("layoutWidget6"));
        layoutWidget6->setGeometry(QRect(200, 400, 191, 123));
        gridLayout_3 = new QGridLayout(layoutWidget6);
        gridLayout_3->setObjectName(QString::fromUtf8("gridLayout_3"));
        gridLayout_3->setContentsMargins(0, 0, 0, 0);
        label_5 = new QLabel(layoutWidget6);
        label_5->setObjectName(QString::fromUtf8("label_5"));

        gridLayout_3->addWidget(label_5, 0, 0, 1, 1);

        spinBoxBinQuatA = new QSpinBox(layoutWidget6);
        spinBoxBinQuatA->setObjectName(QString::fromUtf8("spinBoxBinQuatA"));

        gridLayout_3->addWidget(spinBoxBinQuatA, 0, 1, 1, 3);

        label_6 = new QLabel(layoutWidget6);
        label_6->setObjectName(QString::fromUtf8("label_6"));

        gridLayout_3->addWidget(label_6, 0, 4, 1, 1);

        spinBoxBinQuatB = new QSpinBox(layoutWidget6);
        spinBoxBinQuatB->setObjectName(QString::fromUtf8("spinBoxBinQuatB"));

        gridLayout_3->addWidget(spinBoxBinQuatB, 0, 5, 1, 1);

        label_7 = new QLabel(layoutWidget6);
        label_7->setObjectName(QString::fromUtf8("label_7"));

        gridLayout_3->addWidget(label_7, 1, 0, 1, 3);

        spinBoxBinQuatLimSup = new QSpinBox(layoutWidget6);
        spinBoxBinQuatLimSup->setObjectName(QString::fromUtf8("spinBoxBinQuatLimSup"));

        gridLayout_3->addWidget(spinBoxBinQuatLimSup, 1, 3, 1, 2);

        label_8 = new QLabel(layoutWidget6);
        label_8->setObjectName(QString::fromUtf8("label_8"));

        gridLayout_3->addWidget(label_8, 2, 0, 1, 2);

        spinBoxBinQuatLimInf = new QSpinBox(layoutWidget6);
        spinBoxBinQuatLimInf->setObjectName(QString::fromUtf8("spinBoxBinQuatLimInf"));

        gridLayout_3->addWidget(spinBoxBinQuatLimInf, 2, 2, 1, 3);

        pushButtonBinQuat = new QPushButton(layoutWidget6);
        pushButtonBinQuat->setObjectName(QString::fromUtf8("pushButtonBinQuat"));

        gridLayout_3->addWidget(pushButtonBinQuat, 3, 0, 1, 6);

        layoutWidget7 = new QWidget(centralwidget);
        layoutWidget7->setObjectName(QString::fromUtf8("layoutWidget7"));
        layoutWidget7->setGeometry(QRect(10, 430, 171, 91));
        gridLayout_4 = new QGridLayout(layoutWidget7);
        gridLayout_4->setObjectName(QString::fromUtf8("gridLayout_4"));
        gridLayout_4->setContentsMargins(0, 0, 0, 0);
        label_2 = new QLabel(layoutWidget7);
        label_2->setObjectName(QString::fromUtf8("label_2"));

        gridLayout_4->addWidget(label_2, 0, 0, 1, 1);

        spinBoxBinTerA = new QSpinBox(layoutWidget7);
        spinBoxBinTerA->setObjectName(QString::fromUtf8("spinBoxBinTerA"));

        gridLayout_4->addWidget(spinBoxBinTerA, 0, 1, 1, 2);

        label_3 = new QLabel(layoutWidget7);
        label_3->setObjectName(QString::fromUtf8("label_3"));

        gridLayout_4->addWidget(label_3, 0, 3, 1, 1);

        spinBoxBinTerB = new QSpinBox(layoutWidget7);
        spinBoxBinTerB->setObjectName(QString::fromUtf8("spinBoxBinTerB"));

        gridLayout_4->addWidget(spinBoxBinTerB, 0, 4, 1, 1);

        label_4 = new QLabel(layoutWidget7);
        label_4->setObjectName(QString::fromUtf8("label_4"));

        gridLayout_4->addWidget(label_4, 1, 0, 1, 2);

        spinBoxBinTerLimSup = new QSpinBox(layoutWidget7);
        spinBoxBinTerLimSup->setObjectName(QString::fromUtf8("spinBoxBinTerLimSup"));

        gridLayout_4->addWidget(spinBoxBinTerLimSup, 1, 2, 1, 3);

        pushButtonBinTer = new QPushButton(layoutWidget7);
        pushButtonBinTer->setObjectName(QString::fromUtf8("pushButtonBinTer"));

        gridLayout_4->addWidget(pushButtonBinTer, 2, 0, 1, 5);

        layoutWidget8 = new QWidget(centralwidget);
        layoutWidget8->setObjectName(QString::fromUtf8("layoutWidget8"));
        layoutWidget8->setGeometry(QRect(10, 170, 381, 27));
        horizontalLayout = new QHBoxLayout(layoutWidget8);
        horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
        horizontalLayout->setContentsMargins(0, 0, 0, 0);
        pushButton_2 = new QPushButton(layoutWidget8);
        pushButton_2->setObjectName(QString::fromUtf8("pushButton_2"));
        pushButton_2->setMinimumSize(QSize(170, 0));

        horizontalLayout->addWidget(pushButton_2);

        pushButtonlaplaciano8 = new QPushButton(layoutWidget8);
        pushButtonlaplaciano8->setObjectName(QString::fromUtf8("pushButtonlaplaciano8"));

        horizontalLayout->addWidget(pushButtonlaplaciano8);

        layoutWidget9 = new QWidget(centralwidget);
        layoutWidget9->setObjectName(QString::fromUtf8("layoutWidget9"));
        layoutWidget9->setGeometry(QRect(10, 17, 381, 61));
        gridLayout_5 = new QGridLayout(layoutWidget9);
        gridLayout_5->setObjectName(QString::fromUtf8("gridLayout_5"));
        gridLayout_5->setContentsMargins(0, 0, 0, 0);
        pushButton = new QPushButton(layoutWidget9);
        pushButton->setObjectName(QString::fromUtf8("pushButton"));

        gridLayout_5->addWidget(pushButton, 0, 0, 1, 1);

        lineImagePath = new QLineEdit(layoutWidget9);
        lineImagePath->setObjectName(QString::fromUtf8("lineImagePath"));

        gridLayout_5->addWidget(lineImagePath, 0, 1, 1, 1);

        pushButtonLoadPpm = new QPushButton(layoutWidget9);
        pushButtonLoadPpm->setObjectName(QString::fromUtf8("pushButtonLoadPpm"));

        gridLayout_5->addWidget(pushButtonLoadPpm, 1, 0, 1, 1);

        layoutWidget10 = new QWidget(centralwidget);
        layoutWidget10->setObjectName(QString::fromUtf8("layoutWidget10"));
        layoutWidget10->setGeometry(QRect(202, 210, 191, 27));
        horizontalLayout_4 = new QHBoxLayout(layoutWidget10);
        horizontalLayout_4->setObjectName(QString::fromUtf8("horizontalLayout_4"));
        horizontalLayout_4->setContentsMargins(0, 0, 0, 0);
        ButtonR = new QPushButton(layoutWidget10);
        ButtonR->setObjectName(QString::fromUtf8("ButtonR"));

        horizontalLayout_4->addWidget(ButtonR);

        ButtonG = new QPushButton(layoutWidget10);
        ButtonG->setObjectName(QString::fromUtf8("ButtonG"));

        horizontalLayout_4->addWidget(ButtonG);

        ButtonB = new QPushButton(layoutWidget10);
        ButtonB->setObjectName(QString::fromUtf8("ButtonB"));

        horizontalLayout_4->addWidget(ButtonB);

        textEditLogs = new QTextEdit(centralwidget);
        textEditLogs->setObjectName(QString::fromUtf8("textEditLogs"));
        textEditLogs->setGeometry(QRect(10, 530, 931, 171));
        textEditLogs->setReadOnly(true);
        MainWindow->setCentralWidget(centralwidget);
        menubar = new QMenuBar(MainWindow);
        menubar->setObjectName(QString::fromUtf8("menubar"));
        menubar->setGeometry(QRect(0, 0, 953, 22));
        MainWindow->setMenuBar(menubar);
        statusbar = new QStatusBar(MainWindow);
        statusbar->setObjectName(QString::fromUtf8("statusbar"));
        MainWindow->setStatusBar(statusbar);

        retranslateUi(MainWindow);

        QMetaObject::connectSlotsByName(MainWindow);
    } // setupUi

    void retranslateUi(QMainWindow *MainWindow)
    {
        MainWindow->setWindowTitle(QCoreApplication::translate("MainWindow", "MainWindow", nullptr));
        image->setText(QString());
        pushButtonMedian->setText(QCoreApplication::translate("MainWindow", "Filtro da Mediana", nullptr));
        pushButtonAverage->setText(QCoreApplication::translate("MainWindow", "Filtro da M\303\251dia", nullptr));
        pushButtonGlobalEq->setText(QCoreApplication::translate("MainWindow", "Equaliza\303\247\303\243o Global", nullptr));
        pushButtonBluring->setText(QCoreApplication::translate("MainWindow", "Borrar", nullptr));
        pushButtonHighBoost->setText(QCoreApplication::translate("MainWindow", "Alto Refor\303\247o", nullptr));
        checkBoxSeq->setText(QCoreApplication::translate("MainWindow", "Sequencial", nullptr));
        pushButtonMirror->setText(QCoreApplication::translate("MainWindow", "Espelhamento", nullptr));
        pushButtonNegativo->setText(QCoreApplication::translate("MainWindow", "Negativo", nullptr));
        pushButtonTurnMinus90->setText(QCoreApplication::translate("MainWindow", "-90\302\272", nullptr));
        pushButtonTurnPlus90->setText(QCoreApplication::translate("MainWindow", "90\302\272", nullptr));
        pushButtonTurnPlus180->setText(QCoreApplication::translate("MainWindow", "180\302\272", nullptr));
        pushButtonBinarizing->setText(QCoreApplication::translate("MainWindow", "Binariza\303\247\303\243o", nullptr));
        pushButtonDarken->setText(QCoreApplication::translate("MainWindow", "Escurecer", nullptr));
        pushButtonWhiten->setText(QCoreApplication::translate("MainWindow", "Clarear", nullptr));
        label_5->setText(QCoreApplication::translate("MainWindow", "A", nullptr));
        label_6->setText(QCoreApplication::translate("MainWindow", "B", nullptr));
        label_7->setText(QCoreApplication::translate("MainWindow", "Lim Sup", nullptr));
        label_8->setText(QCoreApplication::translate("MainWindow", "Lim Inf", nullptr));
        pushButtonBinQuat->setText(QCoreApplication::translate("MainWindow", "Binariza\303\247\303\243o Quatern\303\241ria", nullptr));
        label_2->setText(QCoreApplication::translate("MainWindow", "A", nullptr));
        label_3->setText(QCoreApplication::translate("MainWindow", "B", nullptr));
        label_4->setText(QCoreApplication::translate("MainWindow", "Lim Sup", nullptr));
        pushButtonBinTer->setText(QCoreApplication::translate("MainWindow", "Binariza\303\247\303\243o Tern\303\241ria", nullptr));
        pushButton_2->setText(QCoreApplication::translate("MainWindow", "Laplanciano / Diagonal", nullptr));
        pushButtonlaplaciano8->setText(QCoreApplication::translate("MainWindow", "Laplaciano / Vizinhan\303\247a-8", nullptr));
        pushButton->setText(QCoreApplication::translate("MainWindow", "PPM", nullptr));
        lineImagePath->setText(QCoreApplication::translate("MainWindow", "/home/caiotavares/Documentos/UNESP/pdi/photostop-v4/resources/lennap3.ppm", nullptr));
        pushButtonLoadPpm->setText(QCoreApplication::translate("MainWindow", "PGM", nullptr));
        ButtonR->setText(QCoreApplication::translate("MainWindow", "R", nullptr));
        ButtonG->setText(QCoreApplication::translate("MainWindow", "G", nullptr));
        ButtonB->setText(QCoreApplication::translate("MainWindow", "B", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MainWindow: public Ui_MainWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MAINWINDOW_H
