/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.9)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../photostop-v4/src/headers/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.9. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_MainWindow_t {
    QByteArrayData data[35];
    char stringdata0[785];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_MainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_MainWindow_t qt_meta_stringdata_MainWindow = {
    {
QT_MOC_LITERAL(0, 0, 10), // "MainWindow"
QT_MOC_LITERAL(1, 11, 11), // "pgm_buttons"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 9), // "setButton"
QT_MOC_LITERAL(4, 34, 11), // "ppm_buttons"
QT_MOC_LITERAL(5, 46, 12), // "getImagePath"
QT_MOC_LITERAL(6, 59, 11), // "applyFilter"
QT_MOC_LITERAL(7, 71, 9), // "imagePath"
QT_MOC_LITERAL(8, 81, 19), // "ImageFilterFunction"
QT_MOC_LITERAL(9, 101, 14), // "filterFunction"
QT_MOC_LITERAL(10, 116, 22), // "ImageFilterFunctionPgm"
QT_MOC_LITERAL(11, 139, 17), // "filterFunctionPgm"
QT_MOC_LITERAL(12, 157, 14), // "outputFilename"
QT_MOC_LITERAL(13, 172, 21), // "on_pushButton_clicked"
QT_MOC_LITERAL(14, 194, 27), // "on_pushButtonMedian_clicked"
QT_MOC_LITERAL(15, 222, 28), // "on_pushButtonAverage_clicked"
QT_MOC_LITERAL(16, 251, 23), // "on_pushButton_2_clicked"
QT_MOC_LITERAL(17, 275, 18), // "on_ButtonR_clicked"
QT_MOC_LITERAL(18, 294, 18), // "on_ButtonG_clicked"
QT_MOC_LITERAL(19, 313, 18), // "on_ButtonB_clicked"
QT_MOC_LITERAL(20, 332, 30), // "on_pushButtonHighBoost_clicked"
QT_MOC_LITERAL(21, 363, 28), // "on_pushButtonBluring_clicked"
QT_MOC_LITERAL(22, 392, 29), // "on_pushButtonGlobalEq_clicked"
QT_MOC_LITERAL(23, 422, 28), // "on_pushButtonLoadPpm_clicked"
QT_MOC_LITERAL(24, 451, 32), // "on_pushButtonlaplaciano8_clicked"
QT_MOC_LITERAL(25, 484, 29), // "on_pushButtonNegativo_clicked"
QT_MOC_LITERAL(26, 514, 31), // "on_pushButtonTurnPlus90_clicked"
QT_MOC_LITERAL(27, 546, 32), // "on_pushButtonTurnMinus90_clicked"
QT_MOC_LITERAL(28, 579, 32), // "on_pushButtonTurnPlus180_clicked"
QT_MOC_LITERAL(29, 612, 31), // "on_pushButtonBinarizing_clicked"
QT_MOC_LITERAL(30, 644, 27), // "on_pushButtonMirror_clicked"
QT_MOC_LITERAL(31, 672, 27), // "on_pushButtonDarken_clicked"
QT_MOC_LITERAL(32, 700, 27), // "on_pushButtonWhiten_clicked"
QT_MOC_LITERAL(33, 728, 27), // "on_pushButtonBinTer_clicked"
QT_MOC_LITERAL(34, 756, 28) // "on_pushButtonBinQuat_clicked"

    },
    "MainWindow\0pgm_buttons\0\0setButton\0"
    "ppm_buttons\0getImagePath\0applyFilter\0"
    "imagePath\0ImageFilterFunction\0"
    "filterFunction\0ImageFilterFunctionPgm\0"
    "filterFunctionPgm\0outputFilename\0"
    "on_pushButton_clicked\0on_pushButtonMedian_clicked\0"
    "on_pushButtonAverage_clicked\0"
    "on_pushButton_2_clicked\0on_ButtonR_clicked\0"
    "on_ButtonG_clicked\0on_ButtonB_clicked\0"
    "on_pushButtonHighBoost_clicked\0"
    "on_pushButtonBluring_clicked\0"
    "on_pushButtonGlobalEq_clicked\0"
    "on_pushButtonLoadPpm_clicked\0"
    "on_pushButtonlaplaciano8_clicked\0"
    "on_pushButtonNegativo_clicked\0"
    "on_pushButtonTurnPlus90_clicked\0"
    "on_pushButtonTurnMinus90_clicked\0"
    "on_pushButtonTurnPlus180_clicked\0"
    "on_pushButtonBinarizing_clicked\0"
    "on_pushButtonMirror_clicked\0"
    "on_pushButtonDarken_clicked\0"
    "on_pushButtonWhiten_clicked\0"
    "on_pushButtonBinTer_clicked\0"
    "on_pushButtonBinQuat_clicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_MainWindow[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      26,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,  144,    2, 0x08 /* Private */,
       4,    1,  147,    2, 0x08 /* Private */,
       5,    0,  150,    2, 0x08 /* Private */,
       6,    4,  151,    2, 0x08 /* Private */,
      13,    0,  160,    2, 0x08 /* Private */,
      14,    0,  161,    2, 0x08 /* Private */,
      15,    0,  162,    2, 0x08 /* Private */,
      16,    0,  163,    2, 0x08 /* Private */,
      17,    0,  164,    2, 0x08 /* Private */,
      18,    0,  165,    2, 0x08 /* Private */,
      19,    0,  166,    2, 0x08 /* Private */,
      20,    0,  167,    2, 0x08 /* Private */,
      21,    0,  168,    2, 0x08 /* Private */,
      22,    0,  169,    2, 0x08 /* Private */,
      23,    0,  170,    2, 0x08 /* Private */,
      24,    0,  171,    2, 0x08 /* Private */,
      25,    0,  172,    2, 0x08 /* Private */,
      26,    0,  173,    2, 0x08 /* Private */,
      27,    0,  174,    2, 0x08 /* Private */,
      28,    0,  175,    2, 0x08 /* Private */,
      29,    0,  176,    2, 0x08 /* Private */,
      30,    0,  177,    2, 0x08 /* Private */,
      31,    0,  178,    2, 0x08 /* Private */,
      32,    0,  179,    2, 0x08 /* Private */,
      33,    0,  180,    2, 0x08 /* Private */,
      34,    0,  181,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::Void, QMetaType::Bool,    3,
    QMetaType::QString,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 8, 0x80000000 | 10, QMetaType::QString,    7,    9,   11,   12,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void MainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<MainWindow *>(_o);
        (void)_t;
        switch (_id) {
        case 0: _t->pgm_buttons((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 1: _t->ppm_buttons((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: { QString _r = _t->getImagePath();
            if (_a[0]) *reinterpret_cast< QString*>(_a[0]) = std::move(_r); }  break;
        case 3: _t->applyFilter((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const ImageFilterFunction(*)>(_a[2])),(*reinterpret_cast< const ImageFilterFunctionPgm(*)>(_a[3])),(*reinterpret_cast< const QString(*)>(_a[4]))); break;
        case 4: _t->on_pushButton_clicked(); break;
        case 5: _t->on_pushButtonMedian_clicked(); break;
        case 6: _t->on_pushButtonAverage_clicked(); break;
        case 7: _t->on_pushButton_2_clicked(); break;
        case 8: _t->on_ButtonR_clicked(); break;
        case 9: _t->on_ButtonG_clicked(); break;
        case 10: _t->on_ButtonB_clicked(); break;
        case 11: _t->on_pushButtonHighBoost_clicked(); break;
        case 12: _t->on_pushButtonBluring_clicked(); break;
        case 13: _t->on_pushButtonGlobalEq_clicked(); break;
        case 14: _t->on_pushButtonLoadPpm_clicked(); break;
        case 15: _t->on_pushButtonlaplaciano8_clicked(); break;
        case 16: _t->on_pushButtonNegativo_clicked(); break;
        case 17: _t->on_pushButtonTurnPlus90_clicked(); break;
        case 18: _t->on_pushButtonTurnMinus90_clicked(); break;
        case 19: _t->on_pushButtonTurnPlus180_clicked(); break;
        case 20: _t->on_pushButtonBinarizing_clicked(); break;
        case 21: _t->on_pushButtonMirror_clicked(); break;
        case 22: _t->on_pushButtonDarken_clicked(); break;
        case 23: _t->on_pushButtonWhiten_clicked(); break;
        case 24: _t->on_pushButtonBinTer_clicked(); break;
        case 25: _t->on_pushButtonBinQuat_clicked(); break;
        default: ;
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject MainWindow::staticMetaObject = { {
    QMetaObject::SuperData::link<QMainWindow::staticMetaObject>(),
    qt_meta_stringdata_MainWindow.data,
    qt_meta_data_MainWindow,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *MainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *MainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_MainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int MainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 26)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 26;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 26)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 26;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
